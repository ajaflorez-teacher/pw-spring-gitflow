package pe.edu.upc.luismurguiamaldonado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LuismurguiamaldonadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LuismurguiamaldonadoApplication.class, args);
	}

}
