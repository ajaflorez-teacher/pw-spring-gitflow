package pe.edu.upc.luismurguiamaldonado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LuismurguiamaldonadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
