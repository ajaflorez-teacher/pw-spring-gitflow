package pe.edu.upc.diegovasquez;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiegovasquezApplicationTests {

	@Test
	void contextLoads() {
	}

}
