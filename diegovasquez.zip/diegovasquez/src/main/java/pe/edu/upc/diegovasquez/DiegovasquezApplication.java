package pe.edu.upc.diegovasquez;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiegovasquezApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiegovasquezApplication.class, args);
	}

}
