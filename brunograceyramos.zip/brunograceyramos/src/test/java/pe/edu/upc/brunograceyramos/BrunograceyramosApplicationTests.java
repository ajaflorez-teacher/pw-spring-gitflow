package pe.edu.upc.brunograceyramos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrunograceyramosApplicationTests {

	@Test
	void contextLoads() {
	}

}
