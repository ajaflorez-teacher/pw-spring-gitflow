package pe.edu.upc.juantorres;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JuantorresApplicationTests {

	@Test
	void contextLoads() {
	}

}
